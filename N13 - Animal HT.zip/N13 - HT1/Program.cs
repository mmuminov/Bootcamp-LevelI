﻿namespace N13___HT1
{
    public class Program
    {
        static void Main(string[] args)
        {
            Sparrow sparrow = new Sparrow();
            sparrow.Fly();

            Tiger tiger = new Tiger();
            tiger.Run();

            GreatWhiteShark greatWhiteShark = new GreatWhiteShark();
            greatWhiteShark.Swim();


        }
    }
}

