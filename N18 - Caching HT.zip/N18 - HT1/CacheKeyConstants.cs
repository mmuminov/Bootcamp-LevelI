﻿namespace N18___HT1;

public static class CacheKeyConstants
{
    public const string Sum = "-sum";
    public const string Min = "-min";
    public const string Max = "-max";
}

